<?php

namespace App\Filament\Resources\InternetTransferResource\Pages;

use App\Filament\Resources\InternetTransferResource;
use Filament\Resources\Pages\CreateRecord;

class CreateInternetTransfer extends CreateRecord
{
    protected static string $resource = InternetTransferResource::class;
}
