<?php

namespace App\Filament\Resources\InternetTransferResource\Pages;

use App\Filament\Resources\InternetTransferResource;
use Filament\Resources\Pages\ViewRecord;

class ViewInternetTransfer extends ViewRecord
{
    protected static string $resource = InternetTransferResource::class;
}
